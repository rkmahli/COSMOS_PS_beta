
package demo.cosmos.core.policy.service.impl;

import java.util.ArrayList;
import java.util.List;
import com.cognizant.cosmos.core.utils.execution.ServiceContext;
import demo.cosmos.core.policy.dao.PolicyDao;
import demo.cosmos.core.policy.dao.entity.Planbreakup;
import demo.cosmos.core.policy.dao.entity.Product;
import demo.cosmos.core.policy.dao.entity.ProductquestionChoice;
import demo.cosmos.core.policy.model.CreateProposal;
import demo.cosmos.core.policy.model.ModelAndView;
import demo.cosmos.core.policy.model.PlansResource;
import demo.cosmos.core.policy.model.PolicyCreationRequestWrapper;
import demo.cosmos.core.policy.model.ProductResource;
import demo.cosmos.core.policy.model.QuestionResource;
import demo.cosmos.core.policy.service.PolicyService;
import demo.cosmos.core.policy.service.mapper.CreateProposalToPolicydetailsMapper;
import demo.cosmos.core.policy.service.mapper.ModelAndViewToStringMapper;
import demo.cosmos.core.policy.service.mapper.PlansResourceToPlanbreakupMapper;
import demo.cosmos.core.policy.service.mapper.PolicyCreationRequestWrapperToPolicydetailsMapper;
import demo.cosmos.core.policy.service.mapper.ProductResourceToProductMapper;
import demo.cosmos.core.policy.service.mapper.QuestionResourceToProductquestionChoiceMapper;
import demo.cosmos.core.policy.service.mapper.StringToStringMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("policyService")
public class PolicyServiceImpl
    implements PolicyService
{

    @Autowired
    private PolicyDao policyDao;
    @Autowired
    private ProductResourceToProductMapper productResourceToProductMapper;
    @Autowired
    private PlansResourceToPlanbreakupMapper plansResourceToPlanbreakupMapper;
    @Autowired
    private QuestionResourceToProductquestionChoiceMapper questionResourceToProductquestionChoiceMapper;
    @Autowired
    private PolicyCreationRequestWrapperToPolicydetailsMapper policyCreationRequestWrapperToPolicydetailsMapper;
    @Autowired
    private CreateProposalToPolicydetailsMapper createProposalToPolicydetailsMapper;
    @Autowired
    private ModelAndViewToStringMapper modelAndViewToStringMapper;
    @Autowired
    private StringToStringMapper stringToStringMapper;

    @Override
    public ProductResource getProductsUsingGET(String productID, ServiceContext context) {
        return productResourceToProductMapper.convertToResource(policyDao.getProductsUsingGET(productID, context.getQueryParams()));
    }

    @Override
    public List<PlansResource> getPlansUsingGET(ServiceContext context) {
        List<PlansResource> plansResourceList = new ArrayList<PlansResource>();
        for (Planbreakup _planbreakup: policyDao.getPlansUsingGET(context.getQueryParams())) {
            plansResourceList.add(plansResourceToPlanbreakupMapper.convertToResource(_planbreakup));
        }
        return plansResourceList;
    }

    @Override
    public List<QuestionResource> getQuestionsUsingGET(ServiceContext context) {
        List<QuestionResource> questionResourceList = new ArrayList<QuestionResource>();
        for (ProductquestionChoice _productquestionChoice: policyDao.getQuestionsUsingGET(context.getQueryParams())) {
            questionResourceList.add(questionResourceToProductquestionChoiceMapper.convertToResource(_productquestionChoice));
        }
        return questionResourceList;
    }

    @Override
    public CreateProposal saveQuoteUsingPOST(PolicyCreationRequestWrapper policyCreationRequestWrapper, ServiceContext context) {
        return createProposalToPolicydetailsMapper.convertToResource(policyDao.saveQuoteUsingPOST(policyCreationRequestWrapperToPolicydetailsMapper.convertToEntity(policyCreationRequestWrapper), context.getQueryParams()));
    }

    @Override
    public ModelAndView errorHtmlUsingGET(ServiceContext context) {
    	//TODO : your code goes here
        return null;
    }

    @Override
    public ModelAndView errorHtmlUsingPOST(String string, ServiceContext context) {
    	//TODO : your code goes here
        return null;
    }

    @Override
    public ModelAndView errorHtmlUsingPUT(String string, ServiceContext context) {
    	//TODO : your code goes here
        return null;
    }

    @Override
    public int errorHtmlUsingDELETE(ServiceContext context) {
    	//TODO : your code goes here
        return 1;
    }
    

}


package demo.cosmos.core.policy.dao;

import java.util.List;
import java.util.Map;
import demo.cosmos.core.policy.dao.entity.Planbreakup;
import demo.cosmos.core.policy.dao.entity.Policydetails;
import demo.cosmos.core.policy.dao.entity.Product;
import demo.cosmos.core.policy.dao.entity.ProductquestionChoice;

public interface PolicyDao {


    Product getProductsUsingGET(String productID, Map<String, ?> headers);

    List<Planbreakup> getPlansUsingGET(Map<String, ?> headers);

    List<ProductquestionChoice> getQuestionsUsingGET(Map<String, ?> headers);

    Policydetails saveQuoteUsingPOST(Policydetails policydetails, Map<String, ?> headers);

}
